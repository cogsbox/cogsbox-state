import React, { useEffect, useMemo, useState, useRef, useReducer } from 'react';
import { ClientActivityEvent, pluginStore } from './pluginStore';
import { isDeepEqual } from './utility';
import { createMetadataContext, toDeconstructedMethods } from './plugins';
import type { CogsPlugin } from './plugins';
import type { StateObject, UpdateTypeDetail } from './CogsState';
import { ClientActivityState, FormEventType } from './store';

const { setHookResult, removeHookResult } = pluginStore.getState();

const PluginInstance = React.memo(
  ({
    stateKey,
    plugin,
    options,
    stateHandler,
  }: {
    stateKey: string;
    plugin: CogsPlugin<any, any, any, any, any>;
    options: any;
    stateHandler: StateObject<any>;
  }) => {
    const [isInitialMount, setIsInitialMount] = useState(true);
    const metadataContext = useMemo(
      () => createMetadataContext(stateKey, plugin.name),
      [stateKey, plugin.name]
    );

    const deconstructed = useMemo(
      () => toDeconstructedMethods(stateHandler),
      [stateHandler]
    );

    const hookContext = useMemo(
      () => ({
        stateKey,
        pluginName: plugin.name,
        isInitialMount,
        options,
        ...deconstructed,
        ...metadataContext,
      }),
      [
        stateKey,
        plugin.name,
        isInitialMount,
        options,
        deconstructed,
        metadataContext,
      ]
    );

    const hookData = plugin.useHook ? plugin.useHook(hookContext) : undefined;

    useEffect(() => {
      setIsInitialMount(false);
    }, []);

    useEffect(() => {
      if (plugin.useHook) setHookResult(stateKey, plugin.name, hookData);
      else removeHookResult(stateKey, plugin.name);
      return () => removeHookResult(stateKey, plugin.name);
    }, [stateKey, plugin.name, !!plugin.useHook, hookData]);

    const lastProcessedOptionsRef = useRef<any>();
    const [isInitialTransform, setIsInitialTransform] = useState(true);

    useEffect(() => {
      if (plugin.transformState) {
        if (!isDeepEqual(options, lastProcessedOptionsRef.current)) {
          plugin.transformState({
            stateKey,
            pluginName: plugin.name,
            options,
            hookData,
            isInitialTransform,
            ...deconstructed,
            ...metadataContext,
          });
          lastProcessedOptionsRef.current = options;
          setIsInitialTransform(false);
        }
      }
    }, [
      stateKey,
      plugin,
      options,
      hookData,
      isInitialTransform,
      deconstructed,
      metadataContext,
    ]);

    const hookDataRef = useRef(hookData);
    hookDataRef.current = hookData;

    useEffect(() => {
      if (!plugin.onUpdate) return;

      const handleUpdate = (update: UpdateTypeDetail) => {
        if (update.stateKey === stateKey) {
          plugin.onUpdate!({
            stateKey,
            pluginName: plugin.name,
            update,
            path: update.path,
            options,
            hookData: hookDataRef.current,
            ...deconstructed,
            ...metadataContext,
          });
        }
      };

      const unsubscribe = pluginStore
        .getState()
        .subscribeToUpdates(handleUpdate);
      return unsubscribe;
    }, [stateKey, plugin, options, deconstructed, metadataContext]);

    useEffect(() => {
      if (!plugin.onFormUpdate) return;

      const handleFormUpdate = (
        event: ClientActivityEvent // Use the proper type
      ) => {
        if (event.stateKey === stateKey) {
          plugin.onFormUpdate!({
            stateKey,
            pluginName: plugin.name,
            path: event.path,
            event: event, // Pass the whole event through, not a transformed version
            options,
            hookData: hookDataRef.current,
            ...deconstructed,
            ...metadataContext,
          });
        }
      };

      const unsubscribe = pluginStore
        .getState()
        .subscribeToFormUpdates(handleFormUpdate);
      return unsubscribe;
    }, [stateKey, plugin, options, deconstructed, metadataContext]);

    return null;
  }
);
/**
 * The main orchestrator component. It reads from the central pluginStore
 * and renders a `PluginInstance` controller for each active plugin.
 */
export function PluginRunner({ children }: { children: React.ReactNode }) {
  // A simple way to force a re-render when the store changes.
  const [, forceUpdate] = useReducer((c) => c + 1, 0);

  // Subscribe to the store. When plugins or their options are added/removed,
  // this component will re-render to update the list of PluginInstances.
  useEffect(() => {
    const unsubscribe = pluginStore.subscribe(forceUpdate);
    return unsubscribe;
  }, []);

  const { pluginOptions, stateHandlers, registeredPlugins } =
    pluginStore.getState();

  return (
    <>
      {/*
        This declarative mapping is the core of the solution.
        React will now manage adding and removing `PluginInstance` components
        as the application state changes, ensuring hooks are handled safely.
      */}
      {Array.from(pluginOptions.entries()).map(([stateKey, pluginMap]) => {
        const stateHandler = stateHandlers.get(stateKey);
        if (!stateHandler) {
          return null; // Don't render a runner if the state handler isn't ready.
        }

        return Array.from(pluginMap.entries()).map(([pluginName, options]) => {
          const plugin = registeredPlugins.find((p) => p.name === pluginName);
          if (!plugin) {
            return null; // Don't render if the plugin is not in the registered list.
          }

          // Render a dedicated, memoized controller for this specific plugin configuration.
          return (
            <PluginInstance
              key={`${stateKey}:${pluginName}`}
              stateKey={stateKey}
              plugin={plugin}
              options={options}
              stateHandler={stateHandler}
            />
          );
        });
      })}

      {children}
    </>
  );
}
